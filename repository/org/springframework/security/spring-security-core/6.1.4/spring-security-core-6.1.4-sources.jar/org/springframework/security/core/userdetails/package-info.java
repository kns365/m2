/*
 * Copyright 2002-2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * The standard interfaces for implementing user data DAOs.
 * <p>
 * Can be the traditional
 * {@link org.springframework.security.core.userdetails.UserDetailsService
 * UserDetailsService} which uses a unique username to identify the user or, for more
 * complex requirements, the
 * {@link org.springframework.security.core.userdetails.AuthenticationUserDetailsService
 * AuthenticationUserDetailsService}.
 */
package org.springframework.security.core.userdetails;
